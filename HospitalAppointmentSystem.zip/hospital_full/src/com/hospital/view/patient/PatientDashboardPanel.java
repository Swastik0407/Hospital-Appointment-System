package com.hospital.view.patient;

import com.hospital.dao.*;
import com.hospital.model.*;
import com.hospital.service.AppointmentService;
import com.hospital.service.AuthService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.util.List;

public class PatientDashboardPanel extends JPanel {

    private final User               user;
    private Patient                  patient;
    private final AppointmentService apptSvc    = new AppointmentService();
    private final PatientDAO         patientDAO = new PatientDAO();
    private final DoctorDAO          doctorDAO  = new DoctorDAO();
    private final SlotDAO            slotDAO    = new SlotDAO();
    private final MedicalRecordDAO   recordDAO  = new MedicalRecordDAO();

    private final DefaultTableModel apptModel = new DefaultTableModel(
        new String[]{"ID","Doctor","Specialization","Date","Slot","Status","Reason"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable apptTable = new JTable(apptModel);

    private final DefaultTableModel recordModel = new DefaultTableModel(
        new String[]{"Record ID","Doctor","Date","Diagnosis","Prescription","Notes"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable recordTable = new JTable(recordModel);

    public PatientDashboardPanel(User user) {
        this.user = user;
        setLayout(new BorderLayout(8,8));
        setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
        loadPatient();
        buildUI();
        loadAppointments();
        loadMedicalRecords();
    }

    private void loadPatient() {
        try { patient = patientDAO.getByUserId(user.getUserId()); }
        catch (Exception ex) { showErr(ex); }
    }

    private void buildUI() {
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabs.addTab("📅 My Appointments", buildAppointmentTab());
        tabs.addTab("📋 Medical History",  buildMedicalTab());
        add(tabs, BorderLayout.CENTER);
    }

    // ── Appointments Tab ─────────────────────────────────────────────────────

    private JPanel buildAppointmentTab() {
        JPanel p = new JPanel(new BorderLayout(8,8));
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        JButton bookBtn   = styled(new JButton("📅 Book Appointment"), new Color(0x1A73E8));
        JButton cancelBtn = styled(new JButton("Cancel Appointment"),  new Color(0xEA4335));
        JButton refreshBtn = new JButton("↻ Refresh");

        bookBtn.addActionListener(e -> openBookDialog());
        cancelBtn.addActionListener(e -> cancelSelected());
        refreshBtn.addActionListener(e -> loadAppointments());

        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        bar.add(bookBtn); bar.add(cancelBtn); bar.add(refreshBtn);

        apptTable.setRowHeight(26);
        apptTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        apptTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        apptTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Color rows by status
        apptTable.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t,v,sel,foc,r,c);
                if (!sel) {
                    String status = apptModel.getValueAt(r, 5).toString();
                    comp.setBackground(switch (status) {
                        case "Completed"  -> new Color(0xE6F4EA);
                        case "Cancelled"  -> new Color(0xFCE8E6);
                        case "Confirmed"  -> new Color(0xE8F0FE);
                        default           -> Color.WHITE;
                    });
                }
                return comp;
            }
        });

        p.add(bar, BorderLayout.NORTH);
        p.add(new JScrollPane(apptTable), BorderLayout.CENTER);
        return p;
    }

    private void loadAppointments() {
        try {
            apptModel.setRowCount(0);
            if (patient == null) return;
            for (Appointment a : apptSvc.getByPatient(patient.getPatientId())) {
                apptModel.addRow(new Object[]{
                    a.getAppointmentId(), a.getDoctorName(), "—",
                    a.getAppointmentDate(), a.getSlotDay() + " " + a.getSlotTime(),
                    a.getStatus(), a.getReason()
                });
            }
        } catch (Exception ex) { showErr(ex); }
    }

    private void openBookDialog() {
        if (patient == null) { JOptionPane.showMessageDialog(this,"Patient profile not found."); return; }
        try {
            List<Doctor> doctors = doctorDAO.getAllDoctors();
            if (doctors.isEmpty()) { JOptionPane.showMessageDialog(this,"No doctors available."); return; }

            JComboBox<Doctor> docBox = new JComboBox<>(doctors.toArray(new Doctor[0]));
            JComboBox<String> dayBox = new JComboBox<>(new String[]{"Mon","Tue","Wed","Thu","Fri","Sat"});
            JTextField dateField     = new JTextField(java.time.LocalDate.now().toString(), 14);
            JTextField reasonField   = new JTextField(20);
            JComboBox<TimeSlot> slotBox = new JComboBox<>();

            // Load slots when doctor or day changes
            Runnable loadSlots = () -> {
                slotBox.removeAllItems();
                Doctor doc = (Doctor) docBox.getSelectedItem();
                String day = (String) dayBox.getSelectedItem();
                if (doc == null) return;
                try {
                    for (TimeSlot s : slotDAO.getAvailableSlots(doc.getDoctorId(), day))
                        slotBox.addItem(s);
                } catch (Exception ex) { showErr(ex); }
            };
            docBox.addActionListener(e -> loadSlots.run());
            dayBox.addActionListener(e -> loadSlots.run());
            loadSlots.run();

            JPanel p = new JPanel(new GridLayout(0,2,8,8));
            p.add(new JLabel("Doctor *:"));       p.add(docBox);
            p.add(new JLabel("Day *:"));           p.add(dayBox);
            p.add(new JLabel("Slot *:"));          p.add(slotBox);
            p.add(new JLabel("Date (YYYY-MM-DD) *:")); p.add(dateField);
            p.add(new JLabel("Reason:"));          p.add(reasonField);

            int res = JOptionPane.showConfirmDialog(this, p, "Book Appointment", JOptionPane.OK_CANCEL_OPTION);
            if (res != JOptionPane.OK_OPTION) return;

            TimeSlot slot = (TimeSlot) slotBox.getSelectedItem();
            Doctor   doc  = (Doctor)   docBox.getSelectedItem();
            if (slot == null) { JOptionPane.showMessageDialog(this,"No available slots for selected day."); return; }

            Appointment a = new Appointment();
            a.setPatientId(patient.getPatientId());
            a.setDoctorId(doc.getDoctorId());
            a.setSlotId(slot.getSlotId());
            a.setAppointmentDate(Date.valueOf(dateField.getText().trim()));
            a.setReason(reasonField.getText().trim());

            int id = apptSvc.book(a);
            JOptionPane.showMessageDialog(this, "Appointment #" + id + " booked successfully!");
            loadAppointments();
        } catch (Exception ex) { showErr(ex); }
    }

    private void cancelSelected() {
        int row = apptTable.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this,"Select an appointment first."); return; }
        String status = apptModel.getValueAt(row, 5).toString();
        if ("Cancelled".equals(status) || "Completed".equals(status)) {
            JOptionPane.showMessageDialog(this,"Cannot cancel a " + status + " appointment."); return;
        }
        int id = (int) apptModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this,"Cancel appointment #" + id + "?","Confirm",JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try { apptSvc.cancel(id); loadAppointments(); }
            catch (Exception ex) { showErr(ex); }
        }
    }

    // ── Medical History Tab ──────────────────────────────────────────────────

    private JPanel buildMedicalTab() {
        JPanel p = new JPanel(new BorderLayout(8,8));
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        JButton refreshBtn = new JButton("↻ Refresh");
        refreshBtn.addActionListener(e -> loadMedicalRecords());
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bar.add(refreshBtn);

        recordTable.setRowHeight(26);
        recordTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        recordTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        recordTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // View full record on double-click
        recordTable.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) viewRecord();
            }
        });

        p.add(bar, BorderLayout.NORTH);
        p.add(new JScrollPane(recordTable), BorderLayout.CENTER);
        JLabel hint = new JLabel("  Double-click a row to view full record");
        hint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        hint.setForeground(Color.GRAY);
        p.add(hint, BorderLayout.SOUTH);
        return p;
    }

    private void loadMedicalRecords() {
        try {
            recordModel.setRowCount(0);
            if (patient == null) return;
            for (MedicalRecord r : recordDAO.getByPatient(patient.getPatientId())) {
                recordModel.addRow(new Object[]{
                    r.getRecordId(), r.getDoctorName(), r.getAppointmentDate(),
                    truncate(r.getDiagnosis()), truncate(r.getPrescription()), truncate(r.getNotes())
                });
            }
        } catch (Exception ex) { showErr(ex); }
    }

    private void viewRecord() {
        int row = recordTable.getSelectedRow();
        if (row < 0) return;
        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setFont(new Font("Monospaced", Font.PLAIN, 13));
        area.setText(
            "Record ID  : " + recordModel.getValueAt(row,0) + "\n" +
            "Doctor     : " + recordModel.getValueAt(row,1) + "\n" +
            "Date       : " + recordModel.getValueAt(row,2) + "\n\n" +
            "Diagnosis  :\n" + recordModel.getValueAt(row,3) + "\n\n" +
            "Prescription:\n" + recordModel.getValueAt(row,4) + "\n\n" +
            "Notes      :\n" + recordModel.getValueAt(row,5)
        );
        JOptionPane.showMessageDialog(this, new JScrollPane(area), "Medical Record", JOptionPane.INFORMATION_MESSAGE);
    }

    private String truncate(String s) {
        if (s == null) return "—";
        return s.length() > 40 ? s.substring(0,40) + "..." : s;
    }

    private JButton styled(JButton btn, Color bg) {
        btn.setBackground(bg); btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false); return btn;
    }

    private void showErr(Exception ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
