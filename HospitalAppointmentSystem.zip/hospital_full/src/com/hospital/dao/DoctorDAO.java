package com.hospital.dao;

import com.hospital.model.Doctor;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DoctorDAO {

    private Connection conn() throws SQLException {
        return DBConnection.getInstance().getConnection();
    }

    public void createDoctor(Doctor d) throws SQLException {
        String sql = "INSERT INTO doctors (user_id,specialization,phone,available_days,fee) VALUES (?,?,?,?,?)";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, d.getUserId());
            ps.setString(2, d.getSpecialization());
            ps.setString(3, d.getPhone());
            ps.setString(4, d.getAvailableDays());
            ps.setDouble(5, d.getFee());
            ps.executeUpdate();
        }
    }

    public Doctor getByUserId(int userId) throws SQLException {
        String sql = "SELECT d.*, u.name, u.email FROM doctors d " +
                     "JOIN users u ON d.user_id=u.user_id WHERE d.user_id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        }
        return null;
    }

    public Doctor getByDoctorId(int doctorId) throws SQLException {
        String sql = "SELECT d.*, u.name, u.email FROM doctors d " +
                     "JOIN users u ON d.user_id=u.user_id WHERE d.doctor_id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, doctorId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        }
        return null;
    }

    public List<Doctor> getAllDoctors() throws SQLException {
        List<Doctor> list = new ArrayList<>();
        String sql = "SELECT d.*, u.name, u.email FROM doctors d " +
                     "JOIN users u ON d.user_id=u.user_id ORDER BY u.name";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public List<Doctor> getBySpecialization(String spec) throws SQLException {
        List<Doctor> list = new ArrayList<>();
        String sql = "SELECT d.*, u.name, u.email FROM doctors d " +
                     "JOIN users u ON d.user_id=u.user_id WHERE d.specialization LIKE ?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setString(1, "%" + spec + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public void updateDoctor(Doctor d) throws SQLException {
        String sql = "UPDATE doctors SET specialization=?,phone=?,available_days=?,fee=? WHERE doctor_id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setString(1, d.getSpecialization());
            ps.setString(2, d.getPhone());
            ps.setString(3, d.getAvailableDays());
            ps.setDouble(4, d.getFee());
            ps.setInt(5, d.getDoctorId());
            ps.executeUpdate();
        }
    }

    private Doctor map(ResultSet rs) throws SQLException {
        Doctor d = new Doctor();
        d.setDoctorId(rs.getInt("doctor_id"));
        d.setUserId(rs.getInt("user_id"));
        d.setName(rs.getString("name"));
        d.setEmail(rs.getString("email"));
        d.setSpecialization(rs.getString("specialization"));
        d.setPhone(rs.getString("phone"));
        d.setAvailableDays(rs.getString("available_days"));
        d.setFee(rs.getDouble("fee"));
        return d;
    }
}
