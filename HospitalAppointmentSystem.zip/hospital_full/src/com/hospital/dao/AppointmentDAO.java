package com.hospital.dao;

import com.hospital.model.Appointment;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDAO {

    private Connection conn() throws SQLException {
        return DBConnection.getInstance().getConnection();
    }

    private static final String BASE_SQL =
        "SELECT a.*, " +
        "  up.name AS patient_name, " +
        "  ud.name AS doctor_name, " +
        "  ts.slot_time, ts.slot_day " +
        "FROM appointments a " +
        "JOIN patients p   ON a.patient_id = p.patient_id " +
        "JOIN users up     ON p.user_id    = up.user_id " +
        "JOIN doctors d    ON a.doctor_id  = d.doctor_id " +
        "JOIN users ud     ON d.user_id    = ud.user_id " +
        "JOIN time_slots ts ON a.slot_id   = ts.slot_id ";

    /** Book appointment + mark slot unavailable — single transaction */
    public int bookAppointment(Appointment a) throws SQLException {
        Connection c = conn();
        c.setAutoCommit(false);
        try {
            String sql = "INSERT INTO appointments (patient_id,doctor_id,slot_id,appointment_date,reason) VALUES (?,?,?,?,?)";
            int newId;
            try (PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, a.getPatientId());
                ps.setInt(2, a.getDoctorId());
                ps.setInt(3, a.getSlotId());
                ps.setDate(4, a.getAppointmentDate());
                ps.setString(5, a.getReason());
                ps.executeUpdate();
                ResultSet keys = ps.getGeneratedKeys();
                keys.next();
                newId = keys.getInt(1);
            }
            try (PreparedStatement ps = c.prepareStatement(
                     "UPDATE time_slots SET is_available=FALSE WHERE slot_id=?")) {
                ps.setInt(1, a.getSlotId());
                ps.executeUpdate();
            }
            c.commit();
            return newId;
        } catch (SQLException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
    }

    /** Cancel appointment + free slot — single transaction */
    public void cancelAppointment(int appointmentId) throws SQLException {
        Connection c = conn();
        c.setAutoCommit(false);
        try {
            int slotId = getSlotId(appointmentId);
            try (PreparedStatement ps = c.prepareStatement(
                     "UPDATE appointments SET status='Cancelled' WHERE appointment_id=?")) {
                ps.setInt(1, appointmentId);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = c.prepareStatement(
                     "UPDATE time_slots SET is_available=TRUE WHERE slot_id=?")) {
                ps.setInt(1, slotId);
                ps.executeUpdate();
            }
            c.commit();
        } catch (SQLException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
    }

    public void updateStatus(int appointmentId, String status) throws SQLException {
        String sql = "UPDATE appointments SET status=? WHERE appointment_id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, appointmentId);
            ps.executeUpdate();
        }
    }

    public Appointment getById(int id) throws SQLException {
        String sql = BASE_SQL + "WHERE a.appointment_id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        }
        return null;
    }

    public List<Appointment> getByPatient(int patientId) throws SQLException {
        return query(BASE_SQL + "WHERE a.patient_id=? ORDER BY a.appointment_date DESC", patientId);
    }

    public List<Appointment> getByDoctor(int doctorId) throws SQLException {
        return query(BASE_SQL + "WHERE a.doctor_id=? ORDER BY a.appointment_date DESC", doctorId);
    }

    public List<Appointment> getAll() throws SQLException {
        return query(BASE_SQL + "ORDER BY a.appointment_date DESC", -1);
    }

    public int getTotalCount() throws SQLException {
        String sql = "SELECT COUNT(*) FROM appointments";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        }
        return 0;
    }

    public int getTodayCount() throws SQLException {
        String sql = "SELECT COUNT(*) FROM appointments WHERE appointment_date=CURDATE()";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        }
        return 0;
    }

    private List<Appointment> query(String sql, int id) throws SQLException {
        List<Appointment> list = new ArrayList<>();
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            if (id >= 0) ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    private int getSlotId(int appointmentId) throws SQLException {
        String sql = "SELECT slot_id FROM appointments WHERE appointment_id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, appointmentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("slot_id");
        }
        throw new SQLException("Appointment not found: " + appointmentId);
    }

    private Appointment map(ResultSet rs) throws SQLException {
        Appointment a = new Appointment();
        a.setAppointmentId(rs.getInt("appointment_id"));
        a.setPatientId(rs.getInt("patient_id"));
        a.setDoctorId(rs.getInt("doctor_id"));
        a.setSlotId(rs.getInt("slot_id"));
        a.setAppointmentDate(rs.getDate("appointment_date"));
        a.setStatus(rs.getString("status"));
        a.setReason(rs.getString("reason"));
        a.setBookedAt(rs.getTimestamp("booked_at"));
        a.setPatientName(rs.getString("patient_name"));
        a.setDoctorName(rs.getString("doctor_name"));
        a.setSlotTime(rs.getString("slot_time"));
        a.setSlotDay(rs.getString("slot_day"));
        return a;
    }
}
