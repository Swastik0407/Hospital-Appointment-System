package com.hospital.dao;

import com.hospital.model.Patient;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PatientDAO {

    private Connection conn() throws SQLException {
        return DBConnection.getInstance().getConnection();
    }

    public void createPatient(Patient p) throws SQLException {
        String sql = "INSERT INTO patients (user_id,dob,gender,phone,address,blood_group) VALUES (?,?,?,?,?,?)";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, p.getUserId());
            ps.setDate(2, p.getDob());
            ps.setString(3, p.getGender());
            ps.setString(4, p.getPhone());
            ps.setString(5, p.getAddress());
            ps.setString(6, p.getBloodGroup());
            ps.executeUpdate();
        }
    }

    public Patient getByUserId(int userId) throws SQLException {
        String sql = "SELECT p.*, u.name, u.email FROM patients p " +
                     "JOIN users u ON p.user_id=u.user_id WHERE p.user_id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        }
        return null;
    }

    public Patient getByPatientId(int patientId) throws SQLException {
        String sql = "SELECT p.*, u.name, u.email FROM patients p " +
                     "JOIN users u ON p.user_id=u.user_id WHERE p.patient_id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, patientId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        }
        return null;
    }

    public List<Patient> getAllPatients() throws SQLException {
        List<Patient> list = new ArrayList<>();
        String sql = "SELECT p.*, u.name, u.email FROM patients p " +
                     "JOIN users u ON p.user_id=u.user_id ORDER BY u.name";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public void updatePatient(Patient p) throws SQLException {
        String sql = "UPDATE patients SET dob=?,gender=?,phone=?,address=?,blood_group=? WHERE patient_id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setDate(1, p.getDob());
            ps.setString(2, p.getGender());
            ps.setString(3, p.getPhone());
            ps.setString(4, p.getAddress());
            ps.setString(5, p.getBloodGroup());
            ps.setInt(6, p.getPatientId());
            ps.executeUpdate();
        }
    }

    private Patient map(ResultSet rs) throws SQLException {
        Patient p = new Patient();
        p.setPatientId(rs.getInt("patient_id"));
        p.setUserId(rs.getInt("user_id"));
        p.setName(rs.getString("name"));
        p.setEmail(rs.getString("email"));
        p.setDob(rs.getDate("dob"));
        p.setGender(rs.getString("gender"));
        p.setPhone(rs.getString("phone"));
        p.setAddress(rs.getString("address"));
        p.setBloodGroup(rs.getString("blood_group"));
        return p;
    }
}
