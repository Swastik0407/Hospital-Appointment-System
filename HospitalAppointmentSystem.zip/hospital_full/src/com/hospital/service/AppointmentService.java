package com.hospital.service;

import com.hospital.dao.AppointmentDAO;
import com.hospital.dao.MedicalRecordDAO;
import com.hospital.model.Appointment;
import com.hospital.model.MedicalRecord;
import java.sql.SQLException;
import java.util.List;

public class AppointmentService {

    private final AppointmentDAO    apptDAO   = new AppointmentDAO();
    private final MedicalRecordDAO  recordDAO = new MedicalRecordDAO();

    public int book(Appointment a) throws SQLException {
        return apptDAO.bookAppointment(a);
    }

    public void cancel(int appointmentId) throws SQLException {
        apptDAO.cancelAppointment(appointmentId);
    }

    public void confirm(int appointmentId) throws SQLException {
        apptDAO.updateStatus(appointmentId, "Confirmed");
    }

    /**
     * Mark appointment Completed AND create medical record — both must succeed.
     */
    public void complete(int appointmentId, String diagnosis, String prescription, String notes)
            throws SQLException {
        // Check no duplicate record
        if (recordDAO.getByAppointmentId(appointmentId) != null)
            throw new SQLException("Medical record already exists for this appointment.");

        apptDAO.updateStatus(appointmentId, "Completed");

        MedicalRecord r = new MedicalRecord();
        r.setAppointmentId(appointmentId);
        r.setDiagnosis(diagnosis);
        r.setPrescription(prescription);
        r.setNotes(notes);
        recordDAO.createRecord(r);
    }

    public List<Appointment> getByPatient(int patientId) throws SQLException {
        return apptDAO.getByPatient(patientId);
    }

    public List<Appointment> getByDoctor(int doctorId) throws SQLException {
        return apptDAO.getByDoctor(doctorId);
    }

    public List<Appointment> getAll() throws SQLException {
        return apptDAO.getAll();
    }

    public Appointment getById(int id) throws SQLException {
        return apptDAO.getById(id);
    }

    public int getTotalCount()  throws SQLException { return apptDAO.getTotalCount(); }
    public int getTodayCount()  throws SQLException { return apptDAO.getTodayCount(); }
}
