-- ============================================================
-- Hospital Appointment System - Database Schema
-- Database: hospital_db
-- ============================================================

CREATE DATABASE IF NOT EXISTS hospital_db;
USE hospital_db;

-- 1. Users (shared login table for all roles)
CREATE TABLE users (
    user_id    INT PRIMARY KEY AUTO_INCREMENT,
    name       VARCHAR(100) NOT NULL,
    email      VARCHAR(100) UNIQUE NOT NULL,
    password   VARCHAR(64)  NOT NULL,  -- SHA-256 hex
    role       ENUM('admin','doctor','patient') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Patients
CREATE TABLE patients (
    patient_id  INT PRIMARY KEY AUTO_INCREMENT,
    user_id     INT UNIQUE NOT NULL,
    dob         DATE,
    gender      ENUM('Male','Female','Other'),
    phone       VARCHAR(15),
    address     TEXT,
    blood_group VARCHAR(5),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 3. Doctors
CREATE TABLE doctors (
    doctor_id      INT PRIMARY KEY AUTO_INCREMENT,
    user_id        INT UNIQUE NOT NULL,
    specialization VARCHAR(100),
    phone          VARCHAR(15),
    available_days VARCHAR(100),  -- e.g. "Mon,Wed,Fri"
    fee            DECIMAL(8,2) DEFAULT 0.00,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- 4. Time Slots (belong to a doctor, reusable per day)
CREATE TABLE time_slots (
    slot_id      INT PRIMARY KEY AUTO_INCREMENT,
    doctor_id    INT NOT NULL,
    slot_time    TIME NOT NULL,
    slot_day     ENUM('Mon','Tue','Wed','Thu','Fri','Sat') NOT NULL,
    is_available BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id) ON DELETE CASCADE
);

-- 5. Appointments
CREATE TABLE appointments (
    appointment_id   INT PRIMARY KEY AUTO_INCREMENT,
    patient_id       INT NOT NULL,
    doctor_id        INT NOT NULL,
    slot_id          INT NOT NULL,
    appointment_date DATE NOT NULL,
    status           ENUM('Pending','Confirmed','Cancelled','Completed') DEFAULT 'Pending',
    reason           TEXT,
    booked_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    FOREIGN KEY (doctor_id)  REFERENCES doctors(doctor_id),
    FOREIGN KEY (slot_id)    REFERENCES time_slots(slot_id)
);

-- 6. Medical Records (1:1 with appointment, created on completion)
CREATE TABLE medical_records (
    record_id      INT PRIMARY KEY AUTO_INCREMENT,
    appointment_id INT UNIQUE NOT NULL,
    diagnosis      TEXT,
    prescription   TEXT,
    notes          TEXT,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (appointment_id) REFERENCES appointments(appointment_id)
);

-- ============================================================
-- Seed Data
-- ============================================================

-- Default admin (password: admin123)
INSERT INTO users (name, email, password, role) VALUES
('Admin', 'admin@hospital.com',
 '240be518fabd2724ddb6f04eeb1da5967448d7e831d06d456dc0f021c699b8f2', 'admin');

-- Sample doctors (password: doctor123)
INSERT INTO users (name, email, password, role) VALUES
('Dr. Arjun Mehta',  'arjun@hospital.com',
 'ef92b778bafe771207b09bdbee8714e58c7fd2a56d0d54e3cd5c1f9b72f82d4f', 'doctor'),
('Dr. Priya Sharma', 'priya@hospital.com',
 'ef92b778bafe771207b09bdbee8714e58c7fd2a56d0d54e3cd5c1f9b72f82d4f', 'doctor');

INSERT INTO doctors (user_id, specialization, phone, available_days, fee) VALUES
(2, 'Cardiology',  '9800000001', 'Mon,Wed,Fri', 500.00),
(3, 'Dermatology', '9800000002', 'Tue,Thu,Sat', 400.00);

-- Time slots for Doctor 1 (Arjun)
INSERT INTO time_slots (doctor_id, slot_time, slot_day) VALUES
(1,'09:00:00','Mon'),(1,'10:00:00','Mon'),(1,'11:00:00','Mon'),
(1,'09:00:00','Wed'),(1,'10:00:00','Wed'),(1,'11:00:00','Wed'),
(1,'09:00:00','Fri'),(1,'10:00:00','Fri'),(1,'11:00:00','Fri');

-- Time slots for Doctor 2 (Priya)
INSERT INTO time_slots (doctor_id, slot_time, slot_day) VALUES
(2,'10:00:00','Tue'),(2,'11:00:00','Tue'),(2,'12:00:00','Tue'),
(2,'10:00:00','Thu'),(2,'11:00:00','Thu'),(2,'12:00:00','Thu'),
(2,'09:00:00','Sat'),(2,'10:00:00','Sat'),(2,'11:00:00','Sat');

-- Sample patient (password: patient123)
INSERT INTO users (name, email, password, role) VALUES
('Ravi Kumar', 'ravi@gmail.com',
 '5a9f7c5e35c6a8b2c3d1e4f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6', 'patient');

INSERT INTO patients (user_id, dob, gender, phone, address, blood_group) VALUES
(4, '2000-05-15', 'Male', '9700000001', 'Kolkata, WB', 'B+');
