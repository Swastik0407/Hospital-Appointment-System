package com.hospital.model;

import java.sql.Timestamp;

public class MedicalRecord {
    private int       recordId;
    private int       appointmentId;
    private String    diagnosis;
    private String    prescription;
    private String    notes;
    private Timestamp createdAt;

    // Joined display fields
    private String doctorName;
    private String appointmentDate;
    private String patientName;

    public MedicalRecord() {}

    public int       getRecordId()               { return recordId; }
    public void      setRecordId(int id)         { this.recordId = id; }
    public int       getAppointmentId()          { return appointmentId; }
    public void      setAppointmentId(int id)    { this.appointmentId = id; }
    public String    getDiagnosis()              { return diagnosis; }
    public void      setDiagnosis(String d)      { this.diagnosis = d; }
    public String    getPrescription()           { return prescription; }
    public void      setPrescription(String p)   { this.prescription = p; }
    public String    getNotes()                  { return notes; }
    public void      setNotes(String n)          { this.notes = n; }
    public Timestamp getCreatedAt()              { return createdAt; }
    public void      setCreatedAt(Timestamp t)   { this.createdAt = t; }
    public String    getDoctorName()             { return doctorName; }
    public void      setDoctorName(String n)     { this.doctorName = n; }
    public String    getAppointmentDate()        { return appointmentDate; }
    public void      setAppointmentDate(String d){ this.appointmentDate = d; }
    public String    getPatientName()            { return patientName; }
    public void      setPatientName(String n)    { this.patientName = n; }
}
