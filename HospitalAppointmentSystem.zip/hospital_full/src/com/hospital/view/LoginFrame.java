package com.hospital.view;

import com.hospital.dao.PatientDAO;
import com.hospital.dao.UserDAO;
import com.hospital.model.Patient;
import com.hospital.model.User;
import com.hospital.service.AuthService;
import javax.swing.*;
import java.awt.*;
import java.sql.Date;

public class LoginFrame extends JFrame {

    private final JTextField     emailField    = new JTextField(22);
    private final JPasswordField passwordField = new JPasswordField(22);
    private final JButton        loginBtn      = new JButton("Login");
    private final JButton        registerBtn   = new JButton("Register as Patient");
    private final JLabel         statusLabel   = new JLabel(" ");
    private final AuthService    authService   = new AuthService();

    public LoginFrame() {
        setTitle("Hospital Appointment System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        buildUI();
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void buildUI() {
        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(0x1A73E8));
        header.setBorder(BorderFactory.createEmptyBorder(22, 30, 22, 30));
        JLabel title = new JLabel("🏥  Hospital Appointment System");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Color.WHITE);
        header.add(title, BorderLayout.CENTER);

        // Form
        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(30, 40, 10, 40));
        GridBagConstraints g = new GridBagConstraints();
        g.insets  = new Insets(8, 8, 8, 8);
        g.fill    = GridBagConstraints.HORIZONTAL;

        g.gridx=0; g.gridy=0; form.add(new JLabel("Email:"), g);
        g.gridx=1; form.add(emailField, g);

        g.gridx=0; g.gridy=1; form.add(new JLabel("Password:"), g);
        g.gridx=1; form.add(passwordField, g);

        styleBtn(loginBtn,    new Color(0x1A73E8));
        styleBtn(registerBtn, new Color(0x34A853));

        g.gridx=0; g.gridy=2; g.gridwidth=2; g.insets=new Insets(16,8,4,8);
        form.add(loginBtn, g);
        g.gridy=3; g.insets=new Insets(4,8,4,8);
        form.add(registerBtn, g);

        statusLabel.setForeground(Color.RED);
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        g.gridy=4; g.insets=new Insets(4,8,4,8);
        form.add(statusLabel, g);

        // Hint panel
        JPanel hint = new JPanel(new GridLayout(3,1,2,2));
        hint.setBorder(BorderFactory.createEmptyBorder(4,40,12,40));
        hint.add(hint("Admin  : admin@hospital.com / admin123"));
        hint.add(hint("Doctor : arjun@hospital.com / doctor123"));
        hint.add(hint("Patient: ravi@gmail.com / patient123"));

        add(header, BorderLayout.NORTH);
        add(form,   BorderLayout.CENTER);
        add(hint,   BorderLayout.SOUTH);

        loginBtn.addActionListener(e -> doLogin());
        passwordField.addActionListener(e -> doLogin());
        registerBtn.addActionListener(e -> openRegister());
    }

    private void doLogin() {
        String email    = emailField.getText().trim();
        String password = new String(passwordField.getPassword());
        if (email.isEmpty() || password.isEmpty()) {
            statusLabel.setText("Please enter email and password.");
            return;
        }
        loginBtn.setEnabled(false);
        statusLabel.setText("Logging in...");
        new SwingWorker<User, Void>() {
            @Override protected User doInBackground() throws Exception {
                return authService.login(email, password);
            }
            @Override protected void done() {
                try {
                    User user = get();
                    if (user == null) {
                        statusLabel.setText("Invalid email or password.");
                        loginBtn.setEnabled(true);
                    } else {
                        dispose();
                        new MainFrame(user);
                    }
                } catch (Exception ex) {
                    statusLabel.setText("DB Error: " + ex.getMessage());
                    loginBtn.setEnabled(true);
                }
            }
        }.execute();
    }

    private void openRegister() {
        // Simple registration dialog
        JTextField  nameF   = new JTextField(18);
        JTextField  emailF  = new JTextField(18);
        JPasswordField passF = new JPasswordField(18);
        JTextField  phoneF  = new JTextField(18);
        JComboBox<String> genderBox = new JComboBox<>(new String[]{"Male","Female","Other"});
        JTextField  dobF    = new JTextField("YYYY-MM-DD", 18);
        JTextField  bgF     = new JTextField(8);

        JPanel p = new JPanel(new GridLayout(0, 2, 8, 8));
        p.add(new JLabel("Full Name *:"));    p.add(nameF);
        p.add(new JLabel("Email *:"));        p.add(emailF);
        p.add(new JLabel("Password *:"));     p.add(passF);
        p.add(new JLabel("Phone:"));          p.add(phoneF);
        p.add(new JLabel("Gender:"));         p.add(genderBox);
        p.add(new JLabel("DOB (YYYY-MM-DD):")); p.add(dobF);
        p.add(new JLabel("Blood Group:"));    p.add(bgF);

        int res = JOptionPane.showConfirmDialog(this, p, "Patient Registration", JOptionPane.OK_CANCEL_OPTION);
        if (res != JOptionPane.OK_OPTION) return;

        String name  = nameF.getText().trim();
        String email = emailF.getText().trim();
        String pass  = new String(passF.getPassword()).trim();

        if (name.isEmpty() || email.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name, email and password are required.");
            return;
        }

        try {
            UserDAO    userDAO    = new UserDAO();
            PatientDAO patientDAO = new PatientDAO();

            if (userDAO.emailExists(email)) {
                JOptionPane.showMessageDialog(this, "Email already registered."); return;
            }

            User u = new User();
            u.setName(name); u.setEmail(email);
            u.setPassword(AuthService.sha256(pass)); u.setRole("patient");
            int uid = userDAO.createUser(u);

            Patient pt = new Patient();
            pt.setUserId(uid);
            pt.setPhone(phoneF.getText().trim());
            pt.setGender((String) genderBox.getSelectedItem());
            pt.setBloodGroup(bgF.getText().trim());
            pt.setAddress("");
            try {
                String dobStr = dobF.getText().trim();
                if (!dobStr.equals("YYYY-MM-DD") && !dobStr.isEmpty())
                    pt.setDob(Date.valueOf(dobStr));
            } catch (Exception ignored) {}
            patientDAO.createPatient(pt);

            JOptionPane.showMessageDialog(this, "Registration successful! You can now login.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private JLabel hint(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Monospaced", Font.PLAIN, 11));
        l.setForeground(Color.GRAY);
        return l;
    }

    private void styleBtn(JButton btn, Color bg) {
        btn.setBackground(bg); btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false); btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }
}
