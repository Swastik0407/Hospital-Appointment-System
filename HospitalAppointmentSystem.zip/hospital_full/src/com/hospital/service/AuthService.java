package com.hospital.service;

import com.hospital.dao.UserDAO;
import com.hospital.model.User;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;

public class AuthService {

    private static User currentUser;
    private final UserDAO userDAO = new UserDAO();

    public User login(String email, String password) throws SQLException {
        currentUser = userDAO.login(email, sha256(password));
        return currentUser;
    }

    public void logout() { currentUser = null; }

    public static User getCurrentUser()  { return currentUser; }
    public static boolean isAdmin()      { return currentUser != null && "admin".equals(currentUser.getRole()); }
    public static boolean isDoctor()     { return currentUser != null && "doctor".equals(currentUser.getRole()); }
    public static boolean isPatient()    { return currentUser != null && "patient".equals(currentUser.getRole()); }

    public static String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 unavailable", e);
        }
    }
}
