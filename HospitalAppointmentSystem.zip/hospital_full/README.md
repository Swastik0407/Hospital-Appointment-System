# Hospital Appointment System
### Java Swing + MySQL (JDBC) | Group Mini Project

---

## Project Structure

```
hospital/
├── database/
│   └── schema.sql                    ← Run this first in MySQL
└── src/
    └── com/hospital/
        ├── main/
        │   └── Main.java             ← Entry point — run this
        ├── model/                    ← POJOs (data classes, no logic)
        │   ├── User.java
        │   ├── Patient.java
        │   ├── Doctor.java
        │   ├── TimeSlot.java
        │   ├── Appointment.java
        │   └── MedicalRecord.java
        ├── dao/                      ← All SQL lives here, nowhere else
        │   ├── DBConnection.java     ← Singleton JDBC connection (shared)
        │   ├── UserDAO.java
        │   ├── PatientDAO.java
        │   ├── DoctorDAO.java
        │   ├── SlotDAO.java
        │   ├── AppointmentDAO.java
        │   └── MedicalRecordDAO.java
        ├── service/                  ← Business logic, calls DAOs
        │   ├── AuthService.java      ← Login, SHA-256 hashing, session
        │   └── AppointmentService.java ← Booking, cancel, complete
        └── view/                     ← Swing UI panels
            ├── LoginFrame.java       ← Login + Patient registration
            ├── MainFrame.java        ← Top bar + role-based routing
            ├── patient/
            │   └── PatientDashboardPanel.java
            ├── doctor/
            │   └── DoctorDashboardPanel.java
            └── admin/
                └── AdminDashboardPanel.java
```

---

## Database ER Summary

```
users ──< patients ──< appointments >── doctors ──< time_slots
                            │
                     medical_records  (1:1, created on completion)
```

---

## Setup — 3 Steps

### Step 1: MySQL Setup
Open MySQL Workbench or terminal and run:
```bash
mysql -u root -p < database/schema.sql
```
Or paste the contents of `schema.sql` into MySQL Workbench and execute.

### Step 2: Set Your DB Password
Open `src/com/hospital/dao/DBConnection.java` and change:
```java
private static final String PASSWORD = "your_mysql_password";
```

### Step 3: Add MySQL JDBC Driver
Download `mysql-connector-j-8.x.jar` from:
> https://dev.mysql.com/downloads/connector/j/

Add to classpath:
- **IntelliJ IDEA**: File → Project Structure → Libraries → + → Add JAR
- **Eclipse**: Project → Properties → Java Build Path → Libraries → Add External JARs

Then run `com.hospital.main.Main`.

---

## Default Login Credentials

| Role    | Email                   | Password   |
|---------|-------------------------|------------|
| Admin   | admin@hospital.com      | admin123   |
| Doctor  | arjun@hospital.com      | doctor123  |
| Doctor  | priya@hospital.com      | doctor123  |
| Patient | ravi@gmail.com          | patient123 |

New patients can self-register from the Login screen.

---

## Features by Role

### 👤 Patient
- Register a new account from login screen
- Browse doctors by name/specialization
- View available time slots per doctor per day
- Book an appointment (auto-marks slot unavailable)
- Cancel a pending appointment (auto-frees slot)
- View full appointment history with colour-coded status
- View medical history — double-click any row for full details

### 👨‍⚕️ Doctor
- View all appointments (colour-coded by status)
- Confirm a pending appointment
- Mark appointment as Completed + add medical record (diagnosis, prescription, notes) in one action
- View all medical records authored

### 🔐 Admin
- KPI dashboard: total appointments, today's count, total doctors, total patients
- View and manage all appointments (confirm / cancel)
- Add new doctor accounts
- View all patients
- View all medical records
- View and delete user accounts

---

## Module Ownership (for your group)

| Person   | Module              | Key Files                                                   |
|----------|---------------------|-------------------------------------------------------------|
| Person 1 | Patient Module      | PatientDAO, PatientDashboardPanel, LoginFrame (register)    |
| Person 2 | Doctor Module       | DoctorDAO, SlotDAO, DoctorDashboardPanel                    |
| Person 3 | Appointment Module  | AppointmentDAO, AppointmentService, booking/cancel logic    |
| Person 4 | Medical Records     | MedicalRecordDAO, record creation in AppointmentService     |
| Person 5 | Admin Dashboard     | AdminDashboardPanel, UserDAO, all KPI queries               |

**Person 1** owns `DBConnection.java` — all others import it.
**Person 3** owns `AppointmentService.java` — define its interface in Week 1.

---

## Key Viva Points

1. **Atomic transactions** — `bookAppointment()` inserts the appointment AND marks the slot unavailable in a single JDBC transaction. If either step fails, both roll back. Same for `cancelAppointment()`.

2. **DAO pattern** — Zero SQL in View or Service classes. All PreparedStatements live in DAOs only. This is what separates a clean architecture from a messy one.

3. **Role-based routing** — `MainFrame` checks `user.getRole()` and renders either `PatientDashboardPanel`, `DoctorDashboardPanel`, or `AdminDashboardPanel`. One login, three completely different UIs.

4. **SHA-256 password hashing** — Passwords never stored in plain text. `AuthService.sha256()` converts the raw password before any DB call.

5. **Medical record lifecycle** — A record can only be created when an appointment is marked Completed. `AppointmentService.complete()` does both in sequence: `updateStatus("Completed")` then `createRecord()`. If the record already exists, it throws an exception.

6. **Slot reuse design** — Time slots belong to a doctor, not to an appointment. `is_available` is toggled on booking/cancellation, making slots reusable across dates.
