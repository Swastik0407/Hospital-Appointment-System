package com.hospital.dao;

import com.hospital.model.MedicalRecord;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MedicalRecordDAO {

    private Connection conn() throws SQLException {
        return DBConnection.getInstance().getConnection();
    }

    private static final String BASE_SQL =
        "SELECT mr.*, " +
        "  ud.name AS doctor_name, " +
        "  up.name AS patient_name, " +
        "  a.appointment_date " +
        "FROM medical_records mr " +
        "JOIN appointments a ON mr.appointment_id = a.appointment_id " +
        "JOIN doctors d      ON a.doctor_id = d.doctor_id " +
        "JOIN users ud       ON d.user_id   = ud.user_id " +
        "JOIN patients p     ON a.patient_id = p.patient_id " +
        "JOIN users up       ON p.user_id   = up.user_id ";

    public void createRecord(MedicalRecord r) throws SQLException {
        String sql = "INSERT INTO medical_records (appointment_id,diagnosis,prescription,notes) VALUES (?,?,?,?)";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, r.getAppointmentId());
            ps.setString(2, r.getDiagnosis());
            ps.setString(3, r.getPrescription());
            ps.setString(4, r.getNotes());
            ps.executeUpdate();
        }
    }

    public MedicalRecord getByAppointmentId(int appointmentId) throws SQLException {
        String sql = BASE_SQL + "WHERE mr.appointment_id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, appointmentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        }
        return null;
    }

    /** Get all records for a patient */
    public List<MedicalRecord> getByPatient(int patientId) throws SQLException {
        List<MedicalRecord> list = new ArrayList<>();
        String sql = BASE_SQL + "WHERE a.patient_id=? ORDER BY mr.created_at DESC";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, patientId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    /** Get all records written by a doctor */
    public List<MedicalRecord> getByDoctor(int doctorId) throws SQLException {
        List<MedicalRecord> list = new ArrayList<>();
        String sql = BASE_SQL + "WHERE a.doctor_id=? ORDER BY mr.created_at DESC";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, doctorId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public List<MedicalRecord> getAll() throws SQLException {
        List<MedicalRecord> list = new ArrayList<>();
        String sql = BASE_SQL + "ORDER BY mr.created_at DESC";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    private MedicalRecord map(ResultSet rs) throws SQLException {
        MedicalRecord r = new MedicalRecord();
        r.setRecordId(rs.getInt("record_id"));
        r.setAppointmentId(rs.getInt("appointment_id"));
        r.setDiagnosis(rs.getString("diagnosis"));
        r.setPrescription(rs.getString("prescription"));
        r.setNotes(rs.getString("notes"));
        r.setCreatedAt(rs.getTimestamp("created_at"));
        r.setDoctorName(rs.getString("doctor_name"));
        r.setPatientName(rs.getString("patient_name"));
        r.setAppointmentDate(rs.getString("appointment_date"));
        return r;
    }
}
