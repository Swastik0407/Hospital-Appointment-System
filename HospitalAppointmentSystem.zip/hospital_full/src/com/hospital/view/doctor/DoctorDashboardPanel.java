package com.hospital.view.doctor;

import com.hospital.dao.DoctorDAO;
import com.hospital.dao.MedicalRecordDAO;
import com.hospital.model.Appointment;
import com.hospital.model.Doctor;
import com.hospital.model.MedicalRecord;
import com.hospital.model.User;
import com.hospital.service.AppointmentService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class DoctorDashboardPanel extends JPanel {

    private final User               user;
    private Doctor                   doctor;
    private final AppointmentService apptSvc   = new AppointmentService();
    private final DoctorDAO          doctorDAO = new DoctorDAO();
    private final MedicalRecordDAO   recordDAO = new MedicalRecordDAO();

    private final DefaultTableModel apptModel = new DefaultTableModel(
        new String[]{"ID","Patient","Date","Slot","Status","Reason"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable apptTable = new JTable(apptModel);

    private final DefaultTableModel recordModel = new DefaultTableModel(
        new String[]{"Record ID","Patient","Date","Diagnosis","Prescription"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable recordTable = new JTable(recordModel);

    public DoctorDashboardPanel(User user) {
        this.user = user;
        setLayout(new BorderLayout(8,8));
        setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
        loadDoctor();
        buildUI();
        loadAppointments();
        loadRecords();
    }

    private void loadDoctor() {
        try { doctor = doctorDAO.getByUserId(user.getUserId()); }
        catch (Exception ex) { showErr(ex); }
    }

    private void buildUI() {
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabs.addTab("📅 Appointments",    buildAppointmentTab());
        tabs.addTab("📋 Medical Records", buildRecordsTab());
        add(tabs, BorderLayout.CENTER);
    }

    // ── Appointments Tab ─────────────────────────────────────────────────────

    private JPanel buildAppointmentTab() {
        JPanel p = new JPanel(new BorderLayout(8,8));
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        JButton confirmBtn  = styled(new JButton("✔ Confirm"),  new Color(0x1A73E8));
        JButton completeBtn = styled(new JButton("✅ Complete + Add Record"), new Color(0x0F9D58));
        JButton refreshBtn  = new JButton("↻ Refresh");

        confirmBtn.addActionListener(e  -> updateStatus("Confirmed"));
        completeBtn.addActionListener(e -> openCompleteDialog());
        refreshBtn.addActionListener(e  -> loadAppointments());

        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        bar.add(confirmBtn); bar.add(completeBtn); bar.add(refreshBtn);

        apptTable.setRowHeight(26);
        apptTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        apptTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        apptTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        apptTable.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t,v,sel,foc,r,c);
                if (!sel) {
                    String status = apptModel.getValueAt(r, 4).toString();
                    comp.setBackground(switch (status) {
                        case "Completed" -> new Color(0xE6F4EA);
                        case "Cancelled" -> new Color(0xFCE8E6);
                        case "Confirmed" -> new Color(0xE8F0FE);
                        default          -> Color.WHITE;
                    });
                }
                return comp;
            }
        });

        p.add(bar, BorderLayout.NORTH);
        p.add(new JScrollPane(apptTable), BorderLayout.CENTER);
        return p;
    }

    private void loadAppointments() {
        try {
            apptModel.setRowCount(0);
            if (doctor == null) return;
            for (Appointment a : apptSvc.getByDoctor(doctor.getDoctorId())) {
                apptModel.addRow(new Object[]{
                    a.getAppointmentId(), a.getPatientName(),
                    a.getAppointmentDate(), a.getSlotDay() + " " + a.getSlotTime(),
                    a.getStatus(), a.getReason()
                });
            }
        } catch (Exception ex) { showErr(ex); }
    }

    private void updateStatus(String status) {
        int row = apptTable.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this,"Select an appointment first."); return; }
        int id = (int) apptModel.getValueAt(row, 0);
        try { apptSvc.confirm(id); loadAppointments(); }
        catch (Exception ex) { showErr(ex); }
    }

    private void openCompleteDialog() {
        int row = apptTable.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this,"Select an appointment first."); return; }
        String status = apptModel.getValueAt(row, 4).toString();
        if ("Completed".equals(status)) { JOptionPane.showMessageDialog(this,"Already completed."); return; }
        if ("Cancelled".equals(status)) { JOptionPane.showMessageDialog(this,"Cannot complete a cancelled appointment."); return; }

        int apptId = (int) apptModel.getValueAt(row, 0);

        JTextArea diagArea   = new JTextArea(4, 30);
        JTextArea presArea   = new JTextArea(4, 30);
        JTextArea notesArea  = new JTextArea(3, 30);

        JPanel p = new JPanel(new GridLayout(0,1,4,4));
        p.add(new JLabel("Diagnosis *:")); p.add(new JScrollPane(diagArea));
        p.add(new JLabel("Prescription *:")); p.add(new JScrollPane(presArea));
        p.add(new JLabel("Additional Notes:")); p.add(new JScrollPane(notesArea));

        int res = JOptionPane.showConfirmDialog(this, p, "Complete Appointment & Add Medical Record",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (res != JOptionPane.OK_OPTION) return;

        String diag = diagArea.getText().trim();
        String pres = presArea.getText().trim();
        if (diag.isEmpty() || pres.isEmpty()) {
            JOptionPane.showMessageDialog(this,"Diagnosis and prescription are required."); return;
        }
        try {
            apptSvc.complete(apptId, diag, pres, notesArea.getText().trim());
            JOptionPane.showMessageDialog(this,"Appointment completed and medical record saved.");
            loadAppointments();
            loadRecords();
        } catch (Exception ex) { showErr(ex); }
    }

    // ── Records Tab ──────────────────────────────────────────────────────────

    private JPanel buildRecordsTab() {
        JPanel p = new JPanel(new BorderLayout(8,8));
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        JButton refreshBtn = new JButton("↻ Refresh");
        refreshBtn.addActionListener(e -> loadRecords());
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bar.add(refreshBtn);

        recordTable.setRowHeight(26);
        recordTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        recordTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));

        p.add(bar, BorderLayout.NORTH);
        p.add(new JScrollPane(recordTable), BorderLayout.CENTER);
        return p;
    }

    private void loadRecords() {
        try {
            recordModel.setRowCount(0);
            if (doctor == null) return;
            for (MedicalRecord r : recordDAO.getByDoctor(doctor.getDoctorId())) {
                recordModel.addRow(new Object[]{
                    r.getRecordId(), r.getPatientName(), r.getAppointmentDate(),
                    truncate(r.getDiagnosis()), truncate(r.getPrescription())
                });
            }
        } catch (Exception ex) { showErr(ex); }
    }

    private String truncate(String s) {
        if (s == null) return "—";
        return s.length() > 40 ? s.substring(0,40) + "..." : s;
    }

    private JButton styled(JButton btn, Color bg) {
        btn.setBackground(bg); btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false); return btn;
    }

    private void showErr(Exception ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
