package com.hospital.model;

public class Doctor {
    private int    doctorId;
    private int    userId;
    private String name;
    private String email;
    private String specialization;
    private String phone;
    private String availableDays;
    private double fee;

    public Doctor() {}

    public int    getDoctorId()               { return doctorId; }
    public void   setDoctorId(int id)         { this.doctorId = id; }
    public int    getUserId()                 { return userId; }
    public void   setUserId(int id)           { this.userId = id; }
    public String getName()                   { return name; }
    public void   setName(String n)           { this.name = n; }
    public String getEmail()                  { return email; }
    public void   setEmail(String e)          { this.email = e; }
    public String getSpecialization()         { return specialization; }
    public void   setSpecialization(String s) { this.specialization = s; }
    public String getPhone()                  { return phone; }
    public void   setPhone(String p)          { this.phone = p; }
    public String getAvailableDays()          { return availableDays; }
    public void   setAvailableDays(String d)  { this.availableDays = d; }
    public double getFee()                    { return fee; }
    public void   setFee(double f)            { this.fee = f; }

    @Override public String toString() { return name + " — " + specialization; }
}
