package com.hospital.view;

import com.hospital.model.User;
import com.hospital.service.AuthService;
import com.hospital.view.admin.AdminDashboardPanel;
import com.hospital.view.doctor.DoctorDashboardPanel;
import com.hospital.view.patient.PatientDashboardPanel;
import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    public MainFrame(User user) {
        setTitle("Hospital Appointment System  —  " + user.getName() + "  [" + user.getRole().toUpperCase() + "]");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 700);
        setMinimumSize(new Dimension(900, 600));
        buildUI(user);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void buildUI(User user) {
        // Top bar
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(new Color(0x1A73E8));
        topBar.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));

        JLabel titleLabel = new JLabel("🏥  Hospital Appointment System");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(Color.WHITE);

        JLabel userLabel = new JLabel("Welcome, " + user.getName() + "  |  " + user.getRole().toUpperCase());
        userLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        userLabel.setForeground(new Color(0xBBDEFB));

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBackground(new Color(0xCC0000));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFocusPainted(false);
        logoutBtn.addActionListener(e -> {
            new AuthService().logout();
            dispose();
            new LoginFrame();
        });

        JPanel left = new JPanel(new GridLayout(2,1));
        left.setOpaque(false);
        left.add(titleLabel);
        left.add(userLabel);

        topBar.add(left,      BorderLayout.WEST);
        topBar.add(logoutBtn, BorderLayout.EAST);

        // Role-based panel
        JPanel content;
        switch (user.getRole()) {
            case "admin"   -> content = new AdminDashboardPanel();
            case "doctor"  -> content = new DoctorDashboardPanel(user);
            case "patient" -> content = new PatientDashboardPanel(user);
            default        -> content = new JPanel();
        }

        add(topBar,  BorderLayout.NORTH);
        add(content, BorderLayout.CENTER);
    }
}
