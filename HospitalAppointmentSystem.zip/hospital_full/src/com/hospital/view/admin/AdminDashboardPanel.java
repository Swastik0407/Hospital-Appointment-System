package com.hospital.view.admin;

import com.hospital.dao.*;
import com.hospital.model.*;
import com.hospital.service.AppointmentService;
import com.hospital.service.AuthService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AdminDashboardPanel extends JPanel {

    private final AppointmentService apptSvc    = new AppointmentService();
    private final DoctorDAO          doctorDAO  = new DoctorDAO();
    private final PatientDAO         patientDAO = new PatientDAO();
    private final UserDAO            userDAO    = new UserDAO();
    private final MedicalRecordDAO   recordDAO  = new MedicalRecordDAO();

    // KPI labels
    private final JLabel totalApptLabel   = kpiLabel("—");
    private final JLabel todayApptLabel   = kpiLabel("—");
    private final JLabel totalDoctorLabel = kpiLabel("—");
    private final JLabel totalPatientLabel= kpiLabel("—");

    public AdminDashboardPanel() {
        setLayout(new BorderLayout(12,12));
        setBorder(BorderFactory.createEmptyBorder(16,16,16,16));
        add(buildKpiRow(),    BorderLayout.NORTH);
        add(buildTabs(),      BorderLayout.CENTER);
        loadKpis();
    }

    // ── KPI Row ───────────────────────────────────────────────────────────────

    private JPanel buildKpiRow() {
        JPanel row = new JPanel(new GridLayout(1,4,12,0));
        row.add(kpiCard("📅 Total Appointments", totalApptLabel,    new Color(0x1A73E8)));
        row.add(kpiCard("🗓 Today's Appointments",todayApptLabel,   new Color(0x0F9D58)));
        row.add(kpiCard("👨‍⚕️ Doctors",           totalDoctorLabel, new Color(0xF4511E)));
        row.add(kpiCard("👤 Patients",            totalPatientLabel,new Color(0x9C27B0)));
        return row;
    }

    private void loadKpis() {
        new SwingWorker<int[], Void>() {
            @Override protected int[] doInBackground() throws Exception {
                return new int[]{
                    apptSvc.getTotalCount(),
                    apptSvc.getTodayCount(),
                    doctorDAO.getAllDoctors().size(),
                    patientDAO.getAllPatients().size()
                };
            }
            @Override protected void done() {
                try {
                    int[] v = get();
                    totalApptLabel.setText(String.valueOf(v[0]));
                    todayApptLabel.setText(String.valueOf(v[1]));
                    totalDoctorLabel.setText(String.valueOf(v[2]));
                    totalPatientLabel.setText(String.valueOf(v[3]));
                } catch (Exception ex) { showErr(ex); }
            }
        }.execute();
    }

    // ── Tabs ──────────────────────────────────────────────────────────────────

    private JTabbedPane buildTabs() {
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabs.addTab("📅 All Appointments", buildAppointmentsTab());
        tabs.addTab("👨‍⚕️ Manage Doctors",   buildDoctorsTab());
        tabs.addTab("👤 Patients",          buildPatientsTab());
        tabs.addTab("📋 Medical Records",   buildRecordsTab());
        tabs.addTab("👥 Users",             buildUsersTab());
        return tabs;
    }

    // ── Appointments Tab ─────────────────────────────────────────────────────

    private JPanel buildAppointmentsTab() {
        DefaultTableModel m = new DefaultTableModel(
            new String[]{"ID","Patient","Doctor","Date","Slot","Status","Reason","Booked At"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(m);
        styleTable(table);

        JButton refreshBtn = new JButton("↻ Refresh");
        JButton confirmBtn = styled(new JButton("Confirm"), new Color(0x1A73E8));
        JButton cancelBtn  = styled(new JButton("Cancel"),  new Color(0xEA4335));

        Runnable load = () -> {
            try {
                m.setRowCount(0);
                for (Appointment a : apptSvc.getAll()) {
                    m.addRow(new Object[]{
                        a.getAppointmentId(), a.getPatientName(), a.getDoctorName(),
                        a.getAppointmentDate(), a.getSlotDay()+" "+a.getSlotTime(),
                        a.getStatus(), a.getReason(), a.getBookedAt()
                    });
                }
            } catch (Exception ex) { showErr(ex); }
        };

        refreshBtn.addActionListener(e -> load.run());
        confirmBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row<0) return;
            int id = (int) m.getValueAt(row,0);
            try { apptSvc.confirm(id); load.run(); loadKpis(); }
            catch (Exception ex) { showErr(ex); }
        });
        cancelBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row<0) return;
            int id = (int) m.getValueAt(row,0);
            try { apptSvc.cancel(id); load.run(); loadKpis(); }
            catch (Exception ex) { showErr(ex); }
        });

        load.run();
        return tabPanel(table, refreshBtn, confirmBtn, cancelBtn);
    }

    // ── Doctors Tab ───────────────────────────────────────────────────────────

    private JPanel buildDoctorsTab() {
        DefaultTableModel m = new DefaultTableModel(
            new String[]{"ID","Name","Email","Specialization","Phone","Available Days","Fee"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(m);
        styleTable(table);

        JButton addBtn     = styled(new JButton("+ Add Doctor"), new Color(0x0F9D58));
        JButton refreshBtn = new JButton("↻ Refresh");

        Runnable load = () -> {
            try {
                m.setRowCount(0);
                for (Doctor d : doctorDAO.getAllDoctors()) {
                    m.addRow(new Object[]{
                        d.getDoctorId(), d.getName(), d.getEmail(),
                        d.getSpecialization(), d.getPhone(),
                        d.getAvailableDays(), String.format("₹%.0f", d.getFee())
                    });
                }
            } catch (Exception ex) { showErr(ex); }
        };

        refreshBtn.addActionListener(e -> load.run());
        addBtn.addActionListener(e -> {
            JTextField nameF  = new JTextField(18);
            JTextField emailF = new JTextField(18);
            JPasswordField passF = new JPasswordField(18);
            JTextField specF  = new JTextField(18);
            JTextField phoneF = new JTextField(18);
            JTextField daysF  = new JTextField("Mon,Wed,Fri", 18);
            JTextField feeF   = new JTextField("500", 10);

            JPanel p = new JPanel(new GridLayout(0,2,8,8));
            p.add(new JLabel("Name *:"));        p.add(nameF);
            p.add(new JLabel("Email *:"));       p.add(emailF);
            p.add(new JLabel("Password *:"));    p.add(passF);
            p.add(new JLabel("Specialization:")); p.add(specF);
            p.add(new JLabel("Phone:"));         p.add(phoneF);
            p.add(new JLabel("Available Days:")); p.add(daysF);
            p.add(new JLabel("Fee (₹):"));       p.add(feeF);

            int res = JOptionPane.showConfirmDialog(this, p, "Add Doctor", JOptionPane.OK_CANCEL_OPTION);
            if (res != JOptionPane.OK_OPTION) return;

            try {
                User u = new User();
                u.setName(nameF.getText().trim());
                u.setEmail(emailF.getText().trim());
                u.setPassword(AuthService.sha256(new String(passF.getPassword())));
                u.setRole("doctor");
                int uid = userDAO.createUser(u);

                Doctor d = new Doctor();
                d.setUserId(uid);
                d.setSpecialization(specF.getText().trim());
                d.setPhone(phoneF.getText().trim());
                d.setAvailableDays(daysF.getText().trim());
                d.setFee(Double.parseDouble(feeF.getText().trim()));
                doctorDAO.createDoctor(d);

                load.run(); loadKpis();
                JOptionPane.showMessageDialog(this,"Doctor added successfully.");
            } catch (Exception ex) { showErr(ex); }
        });

        load.run();
        return tabPanel(table, refreshBtn, addBtn);
    }

    // ── Patients Tab ──────────────────────────────────────────────────────────

    private JPanel buildPatientsTab() {
        DefaultTableModel m = new DefaultTableModel(
            new String[]{"ID","Name","Email","Gender","Phone","DOB","Blood Group"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(m);
        styleTable(table);
        JButton refreshBtn = new JButton("↻ Refresh");
        Runnable load = () -> {
            try {
                m.setRowCount(0);
                for (Patient p : patientDAO.getAllPatients()) {
                    m.addRow(new Object[]{
                        p.getPatientId(), p.getName(), p.getEmail(),
                        p.getGender(), p.getPhone(), p.getDob(), p.getBloodGroup()
                    });
                }
            } catch (Exception ex) { showErr(ex); }
        };
        refreshBtn.addActionListener(e -> load.run());
        load.run();
        return tabPanel(table, refreshBtn);
    }

    // ── Records Tab ───────────────────────────────────────────────────────────

    private JPanel buildRecordsTab() {
        DefaultTableModel m = new DefaultTableModel(
            new String[]{"ID","Patient","Doctor","Appt Date","Diagnosis","Prescription"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(m);
        styleTable(table);
        JButton refreshBtn = new JButton("↻ Refresh");
        Runnable load = () -> {
            try {
                m.setRowCount(0);
                for (MedicalRecord r : recordDAO.getAll()) {
                    m.addRow(new Object[]{
                        r.getRecordId(), r.getPatientName(), r.getDoctorName(),
                        r.getAppointmentDate(), truncate(r.getDiagnosis()), truncate(r.getPrescription())
                    });
                }
            } catch (Exception ex) { showErr(ex); }
        };
        refreshBtn.addActionListener(e -> load.run());
        load.run();
        return tabPanel(table, refreshBtn);
    }

    // ── Users Tab ─────────────────────────────────────────────────────────────

    private JPanel buildUsersTab() {
        DefaultTableModel m = new DefaultTableModel(
            new String[]{"ID","Name","Email","Role","Created At"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(m);
        styleTable(table);

        JButton refreshBtn = new JButton("↻ Refresh");
        JButton deleteBtn  = styled(new JButton("Delete User"), new Color(0xEA4335));

        Runnable load = () -> {
            try {
                m.setRowCount(0);
                for (User u : userDAO.getAllUsers()) {
                    m.addRow(new Object[]{
                        u.getUserId(), u.getName(), u.getEmail(), u.getRole(), u.getCreatedAt()
                    });
                }
            } catch (Exception ex) { showErr(ex); }
        };

        refreshBtn.addActionListener(e -> load.run());
        deleteBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this,"Select a user first."); return; }
            int uid  = (int) m.getValueAt(row, 0);
            String name = m.getValueAt(row,1).toString();
            if (JOptionPane.showConfirmDialog(this,"Delete user '" + name + "'? This cannot be undone.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                try { userDAO.deleteUser(uid); load.run(); loadKpis(); }
                catch (Exception ex) { showErr(ex); }
            }
        });

        load.run();
        return tabPanel(table, refreshBtn, deleteBtn);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private JPanel tabPanel(JTable table, JButton... buttons) {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        for (JButton btn : buttons) bar.add(btn);
        JPanel p = new JPanel(new BorderLayout(8,8));
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        p.add(bar, BorderLayout.NORTH);
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        return p;
    }

    private void styleTable(JTable table) {
        table.setRowHeight(26);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }

    private static JPanel kpiCard(String title, JLabel valueLabel, Color accent) {
        JPanel card = new JPanel(new BorderLayout(4,4));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(accent, 2, true),
            BorderFactory.createEmptyBorder(12,14,12,14)));
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        titleLabel.setForeground(Color.GRAY);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        valueLabel.setForeground(accent);
        card.add(titleLabel,  BorderLayout.NORTH);
        card.add(valueLabel,  BorderLayout.CENTER);
        return card;
    }

    private static JLabel kpiLabel(String text) {
        JLabel l = new JLabel(text, SwingConstants.LEFT);
        l.setFont(new Font("Segoe UI", Font.BOLD, 28));
        return l;
    }

    private JButton styled(JButton btn, Color bg) {
        btn.setBackground(bg); btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false); return btn;
    }

    private String truncate(String s) {
        if (s==null) return "—";
        return s.length()>40 ? s.substring(0,40)+"..." : s;
    }

    private void showErr(Exception ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
