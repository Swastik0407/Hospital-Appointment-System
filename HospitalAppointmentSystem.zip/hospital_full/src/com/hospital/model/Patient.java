package com.hospital.model;

import java.sql.Date;

public class Patient {
    private int    patientId;
    private int    userId;
    private String name;
    private String email;
    private Date   dob;
    private String gender;
    private String phone;
    private String address;
    private String bloodGroup;

    public Patient() {}

    public int    getPatientId()             { return patientId; }
    public void   setPatientId(int id)       { this.patientId = id; }
    public int    getUserId()                { return userId; }
    public void   setUserId(int id)          { this.userId = id; }
    public String getName()                  { return name; }
    public void   setName(String n)          { this.name = n; }
    public String getEmail()                 { return email; }
    public void   setEmail(String e)         { this.email = e; }
    public Date   getDob()                   { return dob; }
    public void   setDob(Date d)             { this.dob = d; }
    public String getGender()                { return gender; }
    public void   setGender(String g)        { this.gender = g; }
    public String getPhone()                 { return phone; }
    public void   setPhone(String p)         { this.phone = p; }
    public String getAddress()               { return address; }
    public void   setAddress(String a)       { this.address = a; }
    public String getBloodGroup()            { return bloodGroup; }
    public void   setBloodGroup(String bg)   { this.bloodGroup = bg; }

    @Override public String toString() { return name; }
}
