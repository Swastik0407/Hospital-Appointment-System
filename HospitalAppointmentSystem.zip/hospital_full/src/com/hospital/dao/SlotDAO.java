package com.hospital.dao;

import com.hospital.model.TimeSlot;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SlotDAO {

    private Connection conn() throws SQLException {
        return DBConnection.getInstance().getConnection();
    }

    public List<TimeSlot> getAvailableSlots(int doctorId, String dayOfWeek) throws SQLException {
        List<TimeSlot> list = new ArrayList<>();
        String sql = "SELECT * FROM time_slots WHERE doctor_id=? AND slot_day=? AND is_available=TRUE ORDER BY slot_time";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, doctorId);
            ps.setString(2, dayOfWeek);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public List<TimeSlot> getAllSlotsByDoctor(int doctorId) throws SQLException {
        List<TimeSlot> list = new ArrayList<>();
        String sql = "SELECT * FROM time_slots WHERE doctor_id=? ORDER BY slot_day, slot_time";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, doctorId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public void setSlotAvailability(int slotId, boolean available) throws SQLException {
        String sql = "UPDATE time_slots SET is_available=? WHERE slot_id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setBoolean(1, available);
            ps.setInt(2, slotId);
            ps.executeUpdate();
        }
    }

    public void addSlot(TimeSlot slot) throws SQLException {
        String sql = "INSERT INTO time_slots (doctor_id,slot_time,slot_day) VALUES (?,?,?)";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, slot.getDoctorId());
            ps.setString(2, slot.getSlotTime());
            ps.setString(3, slot.getSlotDay());
            ps.executeUpdate();
        }
    }

    public void deleteSlot(int slotId) throws SQLException {
        String sql = "DELETE FROM time_slots WHERE slot_id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, slotId);
            ps.executeUpdate();
        }
    }

    private TimeSlot map(ResultSet rs) throws SQLException {
        TimeSlot s = new TimeSlot();
        s.setSlotId(rs.getInt("slot_id"));
        s.setDoctorId(rs.getInt("doctor_id"));
        s.setSlotTime(rs.getString("slot_time"));
        s.setSlotDay(rs.getString("slot_day"));
        s.setAvailable(rs.getBoolean("is_available"));
        return s;
    }
}
