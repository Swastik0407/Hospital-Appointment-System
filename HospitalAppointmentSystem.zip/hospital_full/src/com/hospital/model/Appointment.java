package com.hospital.model;

import java.sql.Date;
import java.sql.Timestamp;

public class Appointment {
    private int       appointmentId;
    private int       patientId;
    private int       doctorId;
    private int       slotId;
    private Date      appointmentDate;
    private String    status;
    private String    reason;
    private Timestamp bookedAt;

    // Joined display fields
    private String patientName;
    private String doctorName;
    private String slotTime;
    private String slotDay;

    public Appointment() {}

    public int       getAppointmentId()           { return appointmentId; }
    public void      setAppointmentId(int id)     { this.appointmentId = id; }
    public int       getPatientId()               { return patientId; }
    public void      setPatientId(int id)         { this.patientId = id; }
    public int       getDoctorId()                { return doctorId; }
    public void      setDoctorId(int id)          { this.doctorId = id; }
    public int       getSlotId()                  { return slotId; }
    public void      setSlotId(int id)            { this.slotId = id; }
    public Date      getAppointmentDate()         { return appointmentDate; }
    public void      setAppointmentDate(Date d)   { this.appointmentDate = d; }
    public String    getStatus()                  { return status; }
    public void      setStatus(String s)          { this.status = s; }
    public String    getReason()                  { return reason; }
    public void      setReason(String r)          { this.reason = r; }
    public Timestamp getBookedAt()                { return bookedAt; }
    public void      setBookedAt(Timestamp t)     { this.bookedAt = t; }
    public String    getPatientName()             { return patientName; }
    public void      setPatientName(String n)     { this.patientName = n; }
    public String    getDoctorName()              { return doctorName; }
    public void      setDoctorName(String n)      { this.doctorName = n; }
    public String    getSlotTime()                { return slotTime; }
    public void      setSlotTime(String t)        { this.slotTime = t; }
    public String    getSlotDay()                 { return slotDay; }
    public void      setSlotDay(String d)         { this.slotDay = d; }
}
