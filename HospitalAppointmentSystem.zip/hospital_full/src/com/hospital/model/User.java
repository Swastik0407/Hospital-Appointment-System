package com.hospital.model;

import java.sql.Timestamp;

public class User {
    private int       userId;
    private String    name;
    private String    email;
    private String    password;
    private String    role;
    private Timestamp createdAt;

    public User() {}
    public User(int userId, String name, String email, String role) {
        this.userId = userId; this.name = name;
        this.email  = email;  this.role = role;
    }

    public int       getUserId()              { return userId; }
    public void      setUserId(int id)        { this.userId = id; }
    public String    getName()                { return name; }
    public void      setName(String n)        { this.name = n; }
    public String    getEmail()               { return email; }
    public void      setEmail(String e)       { this.email = e; }
    public String    getPassword()            { return password; }
    public void      setPassword(String p)    { this.password = p; }
    public String    getRole()                { return role; }
    public void      setRole(String r)        { this.role = r; }
    public Timestamp getCreatedAt()           { return createdAt; }
    public void      setCreatedAt(Timestamp t){ this.createdAt = t; }

    @Override public String toString() { return name + " (" + role + ")"; }
}
