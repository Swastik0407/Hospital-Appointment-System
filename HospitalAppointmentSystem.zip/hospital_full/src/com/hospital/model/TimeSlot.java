package com.hospital.model;

public class TimeSlot {
    private int     slotId;
    private int     doctorId;
    private String  slotTime;
    private String  slotDay;
    private boolean isAvailable;

    public TimeSlot() {}

    public int     getSlotId()           { return slotId; }
    public void    setSlotId(int id)     { this.slotId = id; }
    public int     getDoctorId()         { return doctorId; }
    public void    setDoctorId(int id)   { this.doctorId = id; }
    public String  getSlotTime()         { return slotTime; }
    public void    setSlotTime(String t) { this.slotTime = t; }
    public String  getSlotDay()          { return slotDay; }
    public void    setSlotDay(String d)  { this.slotDay = d; }
    public boolean isAvailable()         { return isAvailable; }
    public void    setAvailable(boolean a){ this.isAvailable = a; }

    @Override public String toString() { return slotDay + " " + slotTime; }
}
